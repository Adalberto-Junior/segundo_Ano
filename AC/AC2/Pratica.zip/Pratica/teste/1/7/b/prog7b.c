#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

int main(void){

   TRISB |= 0x000F;
   TRISBbits.TRISB4 = 1; 
   AD1PCFGbits.PCFG4 = 0;
   AD1CON1bits.SSRC = 7;
   AD1CON1bits.CLRASAM = 1;
   AD1CON3bits.SAMC = 16;
   AD1CON2bits.SMPI = 0;
   AD1CHSbits.CH0SA = 4;
   AD1CON1bits.ON = 1; 
   while(1){
       AD1CON1bits.ASAM = 1; 
       while(IFS1bits.AD1IF == 0);
       int * valor = (int*)(&ADC1BUF0);
       IFS1bits.AD1IF = 0; 
       int freq = 1 + (*valor) /(1023/4);
       
       delay(freq);
       putChar('\r');
       printStr("DS4=");
       putChar(48 + PORTBbits.RB3);
       printStr(", ");

       printStr("DS3=");
       putChar(48 + PORTBbits.RB2);
       printStr(", ");

       printStr("DS2=");
       putChar(48 + PORTBbits.RB1);
       printStr(", ");

       printStr("DS1=");
       putChar(48 +  PORTBbits.RB0);
       putChar('\n');
   }
   return 0;
}
