#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;
    

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
	displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
	displayFlag = 1;
     }
}
unsigned char toBcd(unsigned char value)
{
    return ((value / 10) << 4) + (value % 10);
}



int main(void){

    TRISE = TRISE & 0xfff0;
    TRISB = TRISB & 0x80ff;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0;
    LATDbits.LATD6 = 0;
    LATDbits.LATD5 = 0;

    int last = -1;
    char u = '\0';
    char s = '\0';
    int i=0;
    while(1){
    LATDbits.LATD6 = 0;
    LATDbits.LATD5 = 0;

      do{
        s = u;
	 u = inkey();
	// s = u;

      }while(u != '\0' );



      switch(s){
          case '0':
		  LATE  = (LATE & 0xfff0) | 0x0001;
		  send2displays(toBcd(0));
		  last = 0; 
               break;
	  case '1':
	         LATE  = (LATE & 0xfff0) | 0x0002;
		 send2displays(toBcd('1'));
		 last = 1;
              break;
	  case '2':
	         LATE  = (LATE & 0xfff0) | 0x0004;
		 send2displays(toBcd('2'));
		 last = 2;
	      break;
	  case '3': 
	         LATE  = (LATE & 0xfff0) | 0x0008;
		 send2displays(toBcd('3'));
		 last = 3;
	      break;
	  case '\0':
	            if(last != -1)
		      send2displays(last);
		    else{
		        send2displays(0);
		    }
	      break;
	  default:
	         LATE  = (LATE & 0xfff0) | 0x000f;
		 for(i = 0; i < 100; i++){
		     send2displays(0xFF);
		      delay(10);
		 }
                  LATDbits.LATD5 = 0;
		  LATDbits.LATD6 = 0;
	          LATE  = LATE & 0xfff0;
		  last = -1;
	    break;
      }
       delay(10);
    }
    return 0;
}


