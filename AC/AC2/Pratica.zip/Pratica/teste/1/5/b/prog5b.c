#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
int main(void){
   
    int unsigned  cnt = 0;
    int freq = 10;
    int flag;
    char t = '\0';

    while(1){
          
	  flag = 0;
           t  = inkey();
	   if(t >= '0' && t <= '4')
	        freq = 2 * (1 + (t-48));

	   if(t == '\x0A')  // Enter = 0x0A;
	   {
	      flag = 1;
            }

             putChar('\r');
             printInt(cnt, 10|( 2 <<16));
	    if(flag == 1){
	       printStr(", ");
	       printInt10(freq);
	       printStr(" Hz");
	     }
	    cnt++;
            delay(1000/freq);

	  if(cnt == 100)
             cnt = 0;
          printStr("         ");
    }

}

