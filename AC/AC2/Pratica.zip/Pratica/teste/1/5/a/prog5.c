#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
int main(void){
   
    int unsigned  cnt = 0;
    while(1){
	putChar('\r');
	printInt(cnt, 10| 2 <<10);
        cnt++;
	delay(1);
	if(cnt == 100)
          cnt = 0;
    }

}
