#include <detpic32.h>

#define TRUE 1
#define FALSE 0

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
void send2displays(unsigned char value, int active)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;


    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
   if(active){
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
	displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
	displayFlag = 1;
     }
   }else{
	   LATDbits.LATD6 = 0;
           LATDbits.LATD5 = 0;
	 }
}
unsigned char toBcd(unsigned char value)
{
    return ((value / 10) << 4) + (value % 10);
}

int main(void){
   
    int unsigned  cnt = 0;
    int freq = 10;
    int flag;
    char t = '\0';
    int freqSav = 10;
    int i = 0;
    TRISB = TRISB & 0x80ff;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0;


    while(1){
          
	  flag = 0;
           t  = inkey();
	   if(t >= '0' && t <= '4')
	        freq = 2 * (1 + (t-48));

	   if(t == '\x0A')  // Enter = 0x0A;
	   {
	      flag = 1;
            }

             putChar('\r');
             printInt(cnt, 10|( 2 <<16));
	    if(flag == 1){
	       printStr(", ");
	       printInt10(freq);
	       printStr(" Hz");
	       freqSav = freq;
	     }else
	     {
		  send2displays(toBcd(freqSav), FALSE);
	     }

	    cnt++;
            delay(1000/freq);
	    	i = 0;
	   	 do{
	        	send2displays(toBcd(freqSav), TRUE);
			delay(20);
	        	i++;
	   	 }while(i < (1000 / (20*freq)));
	    

	  if(cnt == 100)
             cnt = 0;
          printStr("         ");
    }

}

