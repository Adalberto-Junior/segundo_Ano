#include<detpic32.h>


int main(void){

    TRISE = TRISE & 0xfff0;
    TRISB = TRISB | 0x000f;
    int aux;
    while(1){
      aux = PORTB;
      LATE = (LATE & 0xfff0) | aux;
    }
    return 0;
}

