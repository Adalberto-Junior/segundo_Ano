#include<detpic32.h>


int main(void){

    TRISE = TRISE & 0xfff0;
    TRISB = TRISB | 0x000f;
    char aux;
    int aux1;
    while(1){
      aux = PORTB;

      if(aux = 0x0)
	LATE = ((LATE & 0xfff0) | aux1) << 3;
      if(aux == 0x1)
        LATE = ((LATE & 0xfff0) | aux1) << 2;
      if(aux == 0x2)
        LATE = ((LATE & 0xfff0) | aux1) >> 2;
      if(aux == 0x3)
        LATE = ((LATE & 0xfff0) | aux1) >> 3;
    }
    return 0;
}

