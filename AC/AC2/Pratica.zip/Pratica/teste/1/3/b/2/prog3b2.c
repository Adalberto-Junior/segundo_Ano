#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

int main(void){

    TRISE = TRISE & 0xfff0;
    int p;
    while(1){
    
      p = readInt10();
      switch(p){
          case 0:
		  LATE  = (LATE & 0xfff0) | 0x0001;
	     break;
	  case 1:
	         LATE  = (LATE & 0xfff0) | 0x0002;
              break;
	  case 2:
	         LATE  = (LATE & 0xfff0) | 0x0004;
	      break;
	  case 3: 
	         LATE  = (LATE & 0xfff0) | 0x0008;
	      break;
	  default:
	         LATE  = (LATE & 0xfff0) | 0x000f;
                 delay(1000);
	         LATE  = LATE & 0xfff0;

      }
    }
    return 0;
}

