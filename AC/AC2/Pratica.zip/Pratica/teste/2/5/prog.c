#include<detpic32.h>
void delay(unsigned int ms){
   resetCoreTimer();
   while(readCoreTimer() < 20000 * ms);
}
void putc(char c){
   while(U2STAbits.UTXBF == 1);
    U2TXREG = c;
}
void putStr(char *str){
   while(*str != '\0'){
      putc(*str);
      str++;
   }
}

int main(void){

   U2MODEbits.BRGH = 0;
   U2BRG = ((PBCLK + 8 * 1200) / (16 * 1200)) - 1;
   U2MODEbits.PDSEL = 0;
   U2MODEbits.STSEL = 0;
   U2STAbits.UTXEN = 1;
   U2STAbits.URXEN = 1;
   U2MODEbits.ON = 1;

   TRISB = TRISB | 0x000F;
   while(1){
      putStr("RB30=");
      //putc(( ( PORTB & 0x000F)));
      putc((48 + PORTBbits.RB3));
      putc((48 + PORTBbits.RB2));
      putc((48 + PORTBbits.RB1));
      putc((48 + PORTBbits.RB0));
      delay(500);
   }


}
