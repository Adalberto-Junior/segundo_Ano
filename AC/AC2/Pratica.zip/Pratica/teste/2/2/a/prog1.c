#include <detpic32.h>
int cnt = 0;
void send2displays(unsigned char value)
{
   static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;
    

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
	displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
	displayFlag = 1;
     }
}
unsigned char toBcd(unsigned char value)
 {
 return ((value / 10) << 4) + (value % 10);
 }

void _int_(4)isrT1(void)
{
    putChar('\r');
    printInt(cnt, 16|2 << 16); 
    cnt++;
    if(cnt == 100)
       cnt = 0;	    
    IFS0bits.T1IF = 0;
}

void _int_(8)isrT2(void)
{   
  //  int i;
    // for(i = 0; i < 100; i++){
       send2displays(toBcd(cnt));
     //}
    IFS0bits.T2IF = 0;
    

}

int main(void){

    TRISB &= 0x80FF;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0; 
    //T1
    T1CONbits.TCKPS = 2;
    PR1 = 31249;
    TMR1 = 0;
    T1CONbits.TON = 1;// Enable timer T1 (must be the last command of the  
    IPC1bits.T1IP = 1; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T1IE = 1; // Enable timer T1 interrupts
    IFS0bits.T1IF = 0; // Reset timer T1 interrupt flag
     //T3:
    T2CONbits.TCKPS = 3; // k = 8;
    PR3 = 49999;
    TMR2 = 0;
    T2CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    IPC2bits.T2IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T2IE = 1; // Enable timer T2 interrupts
    IFS0bits.T2IF = 0; // Reset timer T2 interrupt flag
    EnableInterrupts();
    while(1);
    return 0;
}
