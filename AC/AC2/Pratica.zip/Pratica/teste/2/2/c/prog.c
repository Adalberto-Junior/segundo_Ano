#include <detpic32.h>
int cnt = 0;
volatile int freqN = 31249;
volatile int k = 2;
//volatile int f_out = (PBCLK / 64 ;

void send2displays(unsigned char value)
{
 static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
  static int flag = 0; 

 // select 
 if(flag){
 LATDbits.LATD6 = 1;
 LATDbits.LATD5 = 0;
 LATB = ((LATB & 0x80FF) |( display7Scodes[ value >> 4]) << 8);
 flag = 0;
 }else{
 // select 5
 LATDbits.LATD6 = 0;
 LATDbits.LATD5 = 1;
 LATB = ((LATB & 0x80FF) | (display7Scodes[ value & 0x0f])  << 8);
 flag = 1;
 }
}
unsigned char toBcd(unsigned char value)
 {
 return ((value / 10) << 4) + (value % 10);
 }

void _int_(4)isrT1(void)
{
    putChar('\r');
    printInt(cnt, 16|2 << 16); 
    cnt++;
    if(cnt == 100)
       cnt = 0;	    
    IFS0bits.T1IF = 0;
}

void _int_(8)isrT2(void)
{ 
    send2displays(toBcd(cnt));
    IFS0bits.T2IF = 0;
}

void _int_(27) isr_adc(void) // Replace VECTOR by the A/D vector
 {
  int *val  =(int*) (&ADC1BUF0);
  int value =  (val[0] * 33 + 511) / 1023;
  int freq  = 1 + (value/127);

  int  f_out = PBCLK / 64;
   PR1 = (f_out / freq) - 1;

  AD1CON1bits.ASAM = 1;
  IFS1bits.AD1IF = 0; // Reset AD1IF flag
 }

int main(void){

    TRISB &= 0x80FF;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0; 
    //T1
    T1CONbits.TCKPS = k;
   // PR1 = freqN;
    TMR1 = 0;
    T1CONbits.TON = 1;// Enable timer T1 (must be the last command of the  
    IPC1bits.T1IP = 1; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T1IE = 1; // Enable timer T1 interrupts
    IFS0bits.T1IF = 0; // Reset timer T1 interrupt flag
     //T2:
    T2CONbits.TCKPS = 7; // k = 256;
    PR3 = 19530;
    TMR2 = 0;
    T2CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    IPC2bits.T2IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T2IE = 1; // Enable timer T2 interrupts
    IFS0bits.T2IF = 0; // Reset timer T2 interrupt flag
    //ADC
    TRISBbits.TRISB4 = 1; // RBx digital output disconnected
    AD1PCFGbits.PCFG4= 0; // RBx configured as analog input
    AD1CON1bits.SSRC = 7; // Conversion trigger selection bits: in this
    AD1CON1bits.CLRASAM = 1; // Stop conversions when the 1st A/D converter
    AD1CON3bits.SAMC = 16; // Sample time is 16 TAD (TAD = 100 ns)
    AD1CON2bits.SMPI = 0; // Interrupt is generated after XX samples
    AD1CHSbits.CH0SA = 4 ; // replace x by the desired input
    AD1CON1bits.ON = 1;
    IPC6bits.AD1IP = 2;
    IFS1bits.AD1IF = 0;
    IEC1bits.AD1IE = 1;
    EnableInterrupts();
    while(1);
    return 0;
}
