#include <detpic32.h>

volatile int maxVoltage = 6;
volatile int minVoltage = 0;
volatile int duty = 0;
void _int_(8)isrT2(void)
{
    AD1CON1bits.ASAM = 1;
    IFS0bits.T2IF = 0;
}

int main (void)
{
     TRISBbits.TRISB4 = 1; // RB4 digital output disconnected
     AD1PCFGbits.PCFG4 = 0; // RB4 configured as analog input (AN4)
     AD1CHSbits.CH0SA = 4;
     // OUTRAS CONFIGURAÇÕES:
     AD1CON1bits.SSRC = 7; 
     AD1CON1bits.CLRASAM = 1;
     AD1CON3bits.SAMC = 16;
     AD1CON2bits.SMPI = 3;
     AD1CON1bits.ON = 1;

     //configuraçoes do timer;
    T2CONbits.TCKPS = 5;
    PR2 = 62499;
    TMR2 = 0; 
    T2CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    // timer configuration s
    IPC2bits.T2IP = 2; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T2IE = 1; // Enable timer T3 interrupts
    IFS0bits.T2IF = 0; // Reset timer T3 interrupt flag
    EnableInterrupts();
    
    OC3CONbits.OCM = 6; // PWM mode on OCx; fault pin disabled 
    OC3CONbits.OCTSEL =0;// Use timer T2 as the time base for PWM generation 
    //OC3RS = ((62499 + 1) * duty) / 100; // Ton constant 
    OC3CONbits.ON = 1; // Enable OC1 module
    //OC5:
    OC5CONbits.OCM = 6; // PWM mode on OCx; fault pin disabled
    OC5CONbits.OCTSEL = 0;// Use timer T2 as the time base for PWM generation
    //OC5RS = ((62499 + 1) * duty) / 100; // Ton constant
    OC5CONbits.ON = 1; // Enable OC1 module

     int sum = 0;
     int media = 0;
     int voltage = 0;
     int i;
     int invDuty = 0;
     while(1){
        
	    while(IFS1bits.AD1IF == 0); // Wait while conversion not done;
        int *a = (int*)(&ADC1BUF0);
        for(i = 0; i < 4; i++){
          sum += a[i*4]; 
        }
        media = sum / 4;
        
        voltage = (media * 33 + 511)/1023;
        if(voltage > maxVoltage){
          duty = 100;
	      invDuty = 0;
        }
        if(voltage < minVoltage){
          duty = 0;
	      invDuty = 100;
        }
        OC3RS = (62499 + 1) * (duty/ 100);
	    OC5RS = (62499 + 1) * (invDuty / 100);
	    IFS1bits.AD1IF = 0;
     }
     return 0;

}
