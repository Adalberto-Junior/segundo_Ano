#include<detpic32.h>

void delay(int ms){
  resetCoreTimer();
  while(readCoreTimer() < 20000 * ms);
}
int main(void){

   TRISE = TRISE & 0XFFF0;
   char s = '\0';
   char u = '\0';
   while(1){
      do{
	 s = u;
         u = inkey();
      }while(u != '\0');
       
      if(s == '0'){
         LATEbits.LATE0 = 1;
         LATEbits.LATE1 = 0;
         LATEbits.LATE2 = 0;
         LATEbits.LATE3 = 0;
  
      }
      else if(s == '1'){
         LATEbits.LATE0 = 0;
         LATEbits.LATE1 = 1;
         LATEbits.LATE2 = 0;
         LATEbits.LATE3 = 0;

      }
      else if(s == '2'){
         LATEbits.LATE0 = 0;
         LATEbits.LATE1 = 0;
         LATEbits.LATE2 = 1;
         LATEbits.LATE3 = 0;

      }
      else if(s == '3'){
         LATEbits.LATE0 = 0;
         LATEbits.LATE1 = 0;
         LATEbits.LATE2 = 0;
         LATEbits.LATE3 = 1;

      }else{
         LATEbits.LATE0 = 1;
         LATEbits.LATE1 = 1;
         LATEbits.LATE2 = 1;
         LATEbits.LATE3 = 1;
         delay(1000);
         LATEbits.LATE0 = 1;
         LATEbits.LATE1 = 0;
         LATEbits.LATE2 = 0;
         LATEbits.LATE3 = 0;
	 
      }
   }
   return 0;

}
