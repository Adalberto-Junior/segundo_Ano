#include<detpic32.h>

typedef struct
{
 char mem[100];
 int nchar;
 int posrd;
}t_buf;

volatile t_buf txbuf;

void putc(char byte){
 while(U2STAbits.UTXBF== 1);
   U2TXREG = byte;
}

void putstrInt(char *s){
  while(txbuf.nchar > 0);
  while(*s != '\0'){
      putc(*s);
      s++;
  }
  txbuf.posrd = 0;
  IEC1bits.U2TXIE = 1;
}

void _int_(32) isr_uart2(void){
  if(IFS1bits.U2TXIF == 1){
    if(txbuf.nchar > 0){
      char byte = U2RXREG;
      U2TXREG = byte;
    }else{
      IFS1bits.U2TXIF = 0;
    }
  }
}

int main(void){
   U2MODEbits.BRGH = 0;
   U2BRG = ((PBCLK + 8 * 115200) / (16 * 115200)) - 1;
   U2MODEbits.PDSEL = 0;
   U2MODEbits.STSEL = 0;
   U2STAbits.URXEN = 1;
   U2STAbits.UTXEN = 1;
   U2MODEbits.ON = 1;
   IEC1bits.U2RXIE = 0;
   IEC1bits.U2TXIE = 0;
   IPC8bits.U2IP = 2;
   U2STAbits.UTXISEL = 0;
   EnableInterrupts();
   txbuf.nchar = 0;
   while(1){
    putstrInt("Test string which can be as long as you like as long as it is no longer than 100 characters\n");
   }
   return 0;

}
