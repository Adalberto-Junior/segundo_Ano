#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
	displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
	displayFlag = 1;
     }
}

unsigned char toBcd(unsigned char value)
 {
 return ((value / 10) << 4) + (value % 10);
 }

int main (void)
{
     TRISBbits.TRISB4 = 1; // RB4 digital output disconnected
     TRISB = TRISB & 0x80FF;
     TRISDbits.TRISD5 = 0;
     TRISDbits.TRISD6 = 0;
     AD1PCFGbits.PCFG4 = 0; // RB4 configured as analog input (AN4)
     AD1CHSbits.CH0SA = 4;
     // OUTRAS CONFIGURAÇÕES:
     AD1CON1bits.SSRC = 7; 
     AD1CON1bits.CLRASAM = 1;
     AD1CON3bits.SAMC = 16;
     AD1CON2bits.SMPI = 3;
     AD1CON1bits.ON = 1;
     int cnt = 0;
     int i;
     int v = 0;
     while(1){
        if(cnt == 0){
	   AD1CON1bits.ASAM = 1; // start conversion;
	   while(IFS1bits.AD1IF == 0); // Wait while conversion not done;
           int *p = (int *)(&ADC1BUF0);
       	   int media;
           for(i = 0; i < 4; i++)
            {
              v += p[i*4];
             }
              media = v/4;
              v = (media * 33 + 511)/1023;
              v = toBcd(v); 
	}
        send2displays(v);
	delay(10);
	i = (i + 1) % 20;
	
	
	IFS1bits.AD1IF = 0;
     }
     return 0;
}


