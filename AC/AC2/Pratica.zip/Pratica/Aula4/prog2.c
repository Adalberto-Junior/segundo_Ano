#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

int main(void)
{
    
    TRISE = TRISE & 0xFFF0;
    while(1)
     {
    
         delay(2000);
         LATE =(LATE & 0xFFF0) | 0x0000;
	 delay(2000);
	 LATE =( LATE & 0xFFF0)| 0x0001; 
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0002;
         delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0003;
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0004;
         delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0005;
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0006;
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0007;
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x0008;
	 delay(2000);
         LATE = LATE | 0x0009;
         delay(2000);
         LATE =( LATE & 0xFFF0) | 0x000A;
	 delay(2000);
         LATE =( LATE & 0xFFF0) | 0x000B;
         delay(2000);
         LATE =( LATE & 0xFFF0) | 0x000C;
         delay(2000);
         LATE = LATE  | 0x000D;
         delay(2000);
         LATE =( LATE & 0xFFF0) | 0x000E;
         delay(2000);
         LATE = LATE  | 0x000F;
     }
     return 0;
}

