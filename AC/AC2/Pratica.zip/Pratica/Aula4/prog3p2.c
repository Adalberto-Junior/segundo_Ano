#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

int main(void)
{
   unsigned char segment;
   TRISB  = TRISB & 0x80FF;
   TRISDbits.TRISD5 = 0;
   TRISDbits.TRISD6 = 0; 
   LATDbits.LATD5   = 0;
   LATDbits.LATD6   = 1;

   int i;
   while(1)
   {
     segment = 1;
     for(i = 0; i < 7; i++)
     {
       LATB = (LATB & 0x80ff) | segment;
       delay(500);
       segment = segment << 1;
     }
     
        
 
         delay(1000);

         LATB =((LATB & 0x80FF) | 0x7700);
       
	 delay(1000);

     	 LATB =((LATB & 0x80FF) | 0x7C00);
         
	 delay(1000);

         LATB = (LATB & 0X8FF) | 0X5800;
          
	 delay(1000);

      	 LATB =((LATB & 0x80FF) | 0x5E00);
          
	 delay(1000);

         LATB = (LATB & 0X8FF) | 0X7900;
          
	 delay(1000);

      	 LATB =((LATB & 0x80FF) | 0x7100);
           
	 delay(1000);

         LATB = (LATB & 0X8FF) | 0X7D00;
          
	 delay(1000);

         LATB = (LATB & 0X8FF) | 0X0000;


   }
   return 0;   


}


