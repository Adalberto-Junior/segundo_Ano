#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

int main(void)
{
   unsigned char segment;
   TRISB = TRISB & 0x80FF;
   TRISD = TRISD & 0xFF9F;
   LATDbits.LATD5 = 1;// enable display low (RD5) and disable display high (RD6)
   LATDbits.LATD6 = 0;  
   int i;
   while(1)
   {
     segment = 1;
     for(i = 0; i < 7; i++)
     {
       LATB = (LATB & 0x80ff) | (segment << 8);
       delay(500);
       segment = segment << 1;
     }
     LATDbits.LATD5 = !LATDbits.LATD5;
     LATDbits.LATD6 = !LATDbits.LATD6;

       

   }
   return 0;   


}

