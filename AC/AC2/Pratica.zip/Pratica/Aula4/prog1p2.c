#include <detpic32.h>

int main(void)
{
   TRISB = TRISB & 0x80FF;
   TRISD = TRISD & 0xFF9F;
   LATD  = ((LATD  & 0XFF9F) | 0x0040);
  
   while(1)
   {
      char c;

         c = getChar();
 
      if(c == 'A'| c == 'a' ){
         LATB =((LATB & 0x80FF) | 0x7700);
      }
      else if(c == 'B'| c == 'b' ){
     	 LATB =((LATB & 0x80FF) | 0x7C00);
      }
      else if(c == 'C' | c == 'c'){
      	LATB = (LATB & 0X8FF) | 0X5800;
      }
      else if(c == 'D'| c == 'd' ){
     	 LATB =((LATB & 0x80FF) | 0x5E00);
      }
      else if(c == 'E' | c == 'e'){
        LATB = (LATB & 0X8FF) | 0X7900;
      }
      else if(c == 'F'| c == 'f' ){
     	 LATB =((LATB & 0x80FF) | 0x7100);
      }
      else if(c == 'G' | c == 'g'){
        LATB = (LATB & 0X8FF) | 0X7D00;
      }
      else
	LATB = (LATB & 0X8FF) | 0X0000;


   }
   return 0;   


}
