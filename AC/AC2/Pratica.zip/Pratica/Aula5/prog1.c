#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value)
{
 static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
  // select 
 LATDbits.LATD6 = 1;
 LATDbits.LATD5 = 0;
 LATB = ((LATB & 0x80FF) |( display7Scodes[ value >> 4]) << 8);
 // select 5
 LATDbits.LATD6 = 0;
 LATDbits.LATD5 = 1;
 LATB = ((LATB & 0x80FF) | (display7Scodes[ value & 0x0f])  << 8);
}

int main(void)
{
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD5 = 0;


   TRISB = TRISB & 0x80FF;

  while(1)
  {
  
    send2displays(0x13);
    delay(200);
    send2displays(0x12);
    delay(500);

  }
   return 0;
}

