#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
	displayFlag = 0;
     } 
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
	displayFlag = 1;
     }
}		

int main(void)
{  
    int i;
    int counter;
    TRISD = (TRISD & 0xFF9F);
    TRISB = TRISB & 0x80FF;
    counter = 0;
  while(1)
  {
    i = 0;
    do{
        send2displays(counter);
	delay(20);   //50hz
       i++;
    }while(i < 10); // 0,020s * 10 = 0,2 --> 1/0,2 = 5hz
    //delay(200); // 5hz
    counter++;
    if(counter == 256)
        counter = 0;
  }
   return 0;
}


