#include <detpic32.h>
//int i = 0;

void _int_(4)isrT1(void)
{   
    LATDbits.LATD0 = 1;
    putChar('1');
    IFS0bits.T1IF = 0;
    LATDbits.LATD0 = 0;
}

void _int_(12)isrT3(void)
{ 
    LATDbits.LATD2 = 1;
    putChar('3');
    IFS0bits.T3IF = 0;
    LATDbits.LATD2 = 0;
}

int main(void){
    
    TRISDbits.TRISD0 = 0;
    TRISDbits.TRISD2 = 0;
    //T1
    T1CONbits.TCKPS = 2;
    PR1 = 62499;
    TMR1 = 0;
    T1CONbits.TON = 1;// Enable timer T1 (must be the last command of the  
    IPC1bits.T1IP = 1; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T1IE = 1; // Enable timer T1 interrupts
    IFS0bits.T1IF = 0; // Reset timer T1 interrupt flag
     //T3:
    T3CONbits.TCKPS = 4; // k = 16; fre--25hz
    PR3 = 49999;
    TMR3 = 0;
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    IPC3bits.T3IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T3IE = 1; // Enable timer T3 interrupts
    IFS0bits.T3IF = 0; // Reset timer T3 interrupt flag
    EnableInterrupts();
    while(1);
    return 0;
}

