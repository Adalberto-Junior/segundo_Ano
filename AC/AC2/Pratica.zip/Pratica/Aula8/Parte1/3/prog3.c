#include <detpic32.h>
int i = 0;
void _int_(12)isrT3(void)
{ 
   //i = 0;
   if(i % 2 == 0){
      putChar('.');
    }
    i++;
    IFS0bits.T3IF = 0;
}

int main(void){
    T3CONbits.TCKPS = 7;
    PR3 = 39062;
    TMR2 = 0;
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    // timer configuration s
    IPC3bits.T3IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T3IE = 1; // Enable timer T3 interrupts
    IFS0bits.T3IF = 0; // Reset timer T3 interrupt flag
    EnableInterrupts();
    while(1);
    return 0;
}


