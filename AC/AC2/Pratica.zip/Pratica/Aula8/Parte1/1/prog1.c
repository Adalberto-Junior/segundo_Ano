#include <detpic32.h>



int main(void){
  
    T3CONbits.TCKPS = 7;
    PR3 = 39062;
    TMR2 = 0; 
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
 // timer configuration s
    IPC3bits.T3IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T3IE = 1; // Enable timer T2 interrupts
    IFS0bits.T3IF = 0; // Reset timer T2 interrupt flag
    while(1){
        while(IFS0bits.T3IF == 0);
	IFS0bits.T3IF = 0;
	putChar('.');
    
    }
    return 0;
}
