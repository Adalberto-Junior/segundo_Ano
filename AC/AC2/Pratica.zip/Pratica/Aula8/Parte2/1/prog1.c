#include <detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
int main(void){
  TRISEbits.TRISE0 = 0;
  TRISDbits.TRISD8 = 1;
 // IEC0bits.D8IE = 1; // Enable timer T2 interrupts
  //IFS0bits.D8IF = 0; // Reset timer T2 interrupt flag
  char c;
    while(1){
	c = PORTDbits.RD8;
	LATEbits.LATE0 = 0;
        while(c == 0x0);
	LATEbits.LATE0 = 1;
	delay(3000);
    }
    return 0;
}

