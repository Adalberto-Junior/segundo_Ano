#include<detpic32.h>


int main(void){

    T3CONbits.TCKPS = 2; // k = 4;
    PR3 = 49999;
    TMR3 = 0;
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the 
    
    OC1CONbits.OCM = 6;//PWMmodeonOCx;faultpindisabled
    OC1CONbits.OCTSEL = 1; //UsetimerT2asthetimebaseforPWMgeneration
    OC1RS=12500; //Tonconstant
    OC1CONbits.ON = 1;//Enable OC1 module
    
    while(1){
        while(IFS0bits.T3IF == 0);
	IFS0bits.T3IF = 0;
	putChar('.');
    
    }
    return 0;
}
