#include<detpic32.h>

void setPWM(unsigned int dutyCycle)
 {
 if(dutyCycle >= 0 && dutyCycle <= 100)
   OC1RS = (((49999 + 1) * dutyCycle) / 100) ; // Determine OC1RS as a function of "dutyCycle" 
 }

void _int_(12)isrT3(void)
{
   // putChar('.');
    IFS0bits.T3IF = 0;
}



int main(void){

    T3CONbits.TCKPS = 2; // k = 4;
    PR3 = 49999;
    TMR3 = 0;
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the 
    // timer configuration s
    IPC3bits.T3IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T3IE = 1; // Enable timer T3 interrupts
    IFS0bits.T3IF = 0; // Reset timer T3 interrupt flag
    EnableInterrupts();
    
    OC1CONbits.OCM = 6;//PWMmodeonOCx;faultpindisabled
    OC1CONbits.OCTSEL = 1; //UsetimerT2asthetimebaseforPWMgeneration
   // OC1RS=12500; //Tonconstant
    setPWM(80);
    OC1CONbits.ON = 1;//Enable OC1 module

    while(1);
    return 0;
}

