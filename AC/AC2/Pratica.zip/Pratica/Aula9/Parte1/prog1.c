#include <detpic32.h>
//int i = 0;
volatile int voltage = 0; // global variable

void configureAll(void){
     
     TRISB = TRISB & 0x80FF;
     TRISDbits.TRISD5 = 0;
     TRISDbits.TRISD6 = 0;

     TRISBbits.TRISB4 = 1; // RB4 digital output disconnected
     AD1PCFGbits.PCFG4 = 0; // RB4 configured as analog input (AN4)
     AD1CHSbits.CH0SA = 4;
     // OUTRAS CONFIGURAÇÕES:
     AD1CON1bits.SSRC = 7; 
     AD1CON1bits.CLRASAM = 1;
     AD1CON3bits.SAMC = 16;
     AD1CON2bits.SMPI = 0;
     AD1CON1bits.ON = 1;
     //Configuração de Interrupção
     IPC6bits.AD1IP = 2;  // configure priority of A/D interrupsts;
     IEC1bits.AD1IE = 1;  // enable A/D interrupts;
     //AD1CON1bits.ASAM = 1; // start conversion
      //T1
    T1CONbits.TCKPS = 2;
    PR1 = 62499;
    TMR1 = 0;
    T1CONbits.TON = 1;// Enable timer T1 (must be the last command of the  
    IPC1bits.T1IP = 1; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T1IE = 1; // Enable timer T1 interrupts
   
     //T3:
    T3CONbits.TCKPS = 2; // k = 4;
    PR3 = 49999;
    TMR3 = 0;
    T3CONbits.TON = 1;// Enable timer T2 (must be the last command of the  
    IPC3bits.T3IP = 3; // Interrupt priority (must be in range [1..6]) 
    IEC0bits.T3IE = 1; // Enable timer T3 interrupts
}

void send2displays(unsigned char value)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
        displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
        displayFlag = 1;
     }
}

unsigned char toBcd(unsigned char value)
 {
 return ((value / 10) << 4) + (value % 10);
 }

void _int_(4)isrT1(void)
{
    AD1CON1bits.ASAM = 1; // start conversion
    IFS0bits.T1IF = 0;
}

void _int_(12)isrT3(void)
{ 
    send2displays(voltage);   
    IFS0bits.T3IF = 0;
}

// interrupt hadler
void _int_(27) isdr_adc(void)
{
  int *p = (int *)(&ADC1BUF0);
  int i;
  int A = 0;
  int media;

  for(i = 0; i < 8;i++){
    A += p[i*4];
  }
  media = A / 8;
  A = (media * 33 + 511)/1023;
 // voltage = ((A/10) << 4) + (A % 10);
  voltage = toBcd(A);
  IFS1bits.AD1IF = 0;

  // printInt(ADC1BUF0, 16 | 3 << 16);

}


int main(void){

     configureAll(); // Function to configure all (digital I/O, analog 
                     // input, A/D module, timers T1 and T3, interrupts)
     IFS1bits.AD1IF = 0; 
     IFS0bits.T1IF = 0;
     IFS0bits.T3IF = 0;
     EnableInterrupts();
    while(1);
    return 0;
}

