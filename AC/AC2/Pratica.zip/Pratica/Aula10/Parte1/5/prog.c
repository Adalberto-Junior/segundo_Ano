#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
void putc(char byte){
 while(U2STAbits.UTXBF== 1);
   U2TXREG = byte;
}
char getc(void){
 while(U2STAbits.URXDA== 0);
   return U2RXREG;
}

int main(void)
{
   U2MODEbits.BRGH = 0; // BRGH = 16;
   U2BRG = ((PBCLK + 16 / 2 * 115200)/ (16 * 115200)) - 1;
      //10;  //((PBCLK + 16 / 2 * baudrate)/ (16 * baudrate)) - 1;
   U2MODEbits.PDSEL = 0;
   U2MODEbits.STSEL = 0;
   U2STAbits.URXEN = 1;
   U2STAbits.UTXEN = 1;
   U2MODEbits.ON = 1;
   while(1)
    {
     char c = getc();
     putc(c);
     delay(1000);
    }
   return 0;

}
