#include<detpic32.h>


void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}
void putc(char byte){
 while(U2STAbits.UTXBF== 1);
   U2TXREG = byte;
}
void configUart2(unsigned int baud, char parity, unsigned int stopbits)
{  
   if(baud >= 600 && baud <= 115200){
     U2BRG = ((PBCLK + 16 / 2 * baud)/ (16 * baud)) - 1;
   }
   else{
      U2BRG = ((PBCLK + 16 / 2 * 115200)/ (16 * 115200)) - 1;
   }
   if(parity == 0 || parity == 1 || parity == 2){
     U2MODEbits.PDSEL = parity;
   }else{
     U2MODEbits.PDSEL = 0;
   }
   if(stopbits == 0 || stopbits == 1){
     U2MODEbits.STSEL = stopbits;
   }else{
     U2MODEbits.STSEL = 0;
   }
   U2MODEbits.BRGH = 0; // BRGH = 16;
   U2STAbits.URXEN = 1;
   U2STAbits.UTXEN = 1;
   U2MODEbits.ON = 1;

}
int main(void)
{
   configUart2(600, 2, 1);
   while(1)
    {
     putc('+');
     delay(1000);
    }
   return 0;

}
