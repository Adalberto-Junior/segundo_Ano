#include <detpic32.h>

volatile unsigned char voltage = 0;

// interrupt hadler
void _int_(27) isdr_adc(void)
{
  int *p = (int *)(&ADC1BUF0);
  int i;
  int A = 0;
  int media;

  for(i = 0; i < 8;i++){
    A += p[i*4]; 
  }
  media = A / 8;
  A = (media * 33 + 511)/1023;
  voltage = ((A/10) << 4) + (A % 10);
  IFS1bits.AD1IF = 0;
   
  // printInt(ADC1BUF0, 16 | 3 << 16);
  
}

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value)
{
     static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
    static char displayFlag = 0;

    char dh = display7Scodes[value >> 4];
    char dl = display7Scodes[value & 0x0f];
    if(displayFlag){
        LATDbits.LATD6 = 1;
        LATDbits.LATD5 = 0;
        LATB =  ((LATB & 0x80FF) | dh << 8);
        displayFlag = 0;
     }
     else{
        LATDbits.LATD6 = 0;
        LATDbits.LATD5 = 1;
        LATB = ((LATB & 0x80FF) | dl  << 8);
        displayFlag = 1;
     }
}

int main(void)
{
	unsigned int cnt = 0;
	TRISBbits.TRISB4 = 1;
	TRISDbits.TRISD5 = 0;
	TRISDbits.TRISD6 = 0;
	TRISB = TRISE & 0x80FF;
	AD1PCFGbits.PCFG4 = 0;
	AD1CHSbits.CH0SA = 4;
	// OUTRAS CONFIGURAÇÕES
	AD1CON1bits.SSRC = 7;
	AD1CON1bits.CLRASAM = 1;
	AD1CON3bits.SAMC = 16;
	AD1CON2bits.SMPI = 7;
	AD1CON1bits.ON = 1;
	// CONFIGURE INTERRUPTS MOD
	IPC6bits.AD1IP = 2;
	IFS1bits.AD1IF = 0;
	IEC1bits.AD1IE = 1;
	EnableInterrupts();
	while(1)
	{
		if(cnt == 0)
		{
		 AD1CON1bits.ASAM = 1;
		} 
	       send2displays(voltage);
       	       cnt = (cnt + 1) % 10;
	       delay(200);	       
	}
	return 0;

}
