#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}


int main(void){
   TRISE = TRISE & 0xffc0;
   TRISB = TRISB | 0X0004;
   int aux;
   char aux2 = 0x0001;
   int i = 0;
   while(1){
     aux = (48 + PORTBbits.RB2);
     LATE = (LATE & 0xffc0) | aux2;
     i++;
     aux2 =  aux2 << 1;
     if(i == 6){
     aux2 =( aux2 & 0x0000) | 0x0001;
     }
     if(aux == 0)
	delay(333);
     else
	 delay(143);
   }
   return 0;

}
