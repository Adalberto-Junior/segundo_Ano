#include<detpic32.h>

void delay(unsigned int ms)
{
 resetCoreTimer();
 while(readCoreTimer() < 20000 *  ms);
}

void send2displays(unsigned char value) 
 { 
 static const char display7Scodes[] = {0x3f, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x58, 0x5E, 0x79, 0x71};
  static char displayFlag = 0;
 char dl = display7Scodes[value & 0x0F]; 
 char dh = display7Scodes[value >> 4]; 
 if(displayFlag == 1){
    LATDbits.LATD5 = 0;
    LATDbits.LATD6 = 1;
    LATE = (LATB & 0x80ff) | dh << 8;
    displayFlag = 0;
 }else{
    LATDbits.LATD5 = 1;
    LATDbits.LATD6 = 0;
    LATE = (LATB & 0x80ff) | dl << 8;
    displayFlag = 1;
   }
 }

unsigned char toBcd(unsigned char value)
 {
 return ((value / 10) << 4) + (value % 10);
 }


int main(void){
    TRISB  = TRISB & 0x80ff;
    TRISDbits.TRISD5 = 0;
    TRISDbits.TRISD6 = 0;  
    TRISEbits.TRISE1 = 0;
    TRISBbits.TRISB4  = 1;
    AD1PCFGbits.PCFG4 = 0;
    AD1CON1bits.SSRC = 7;
    AD1CON1bits.CLRASAM = 1;
    AD1CON3bits.SAMC = 16;
    AD1CON2bits.SMPI = 1;
    AD1CHSbits.CH0SA = 4;
    AD1CON1bits.ON = 1;
    int i = 0;
    int j = 0;
    int media = 0;
    int v = 0;
    while(1){
       if(i == 0)
	{
      	   AD1CON1bits.ASAM = 1;
      	   LATEbits.LATE1 = 0;
       	   while( IFS1bits.AD1IF == 0 );
           LATEbits.LATE1 = 1;
	   int *p = (int *)(&ADC1BUF0);
	   for(j = 0; j < 2; j++){
          	 printInt(p[i * 4], 16 | 3 << 16);
		 media += p[i * 4];
	   }
	   IFS1bits.AD1IF = 0;
       media = media / 2;
	   v = (media * 33 + 511)/1023;
	   v = toBcd(v);
	}
        send2displays(v);
        i = (i + 1) % 5;
    }



}
